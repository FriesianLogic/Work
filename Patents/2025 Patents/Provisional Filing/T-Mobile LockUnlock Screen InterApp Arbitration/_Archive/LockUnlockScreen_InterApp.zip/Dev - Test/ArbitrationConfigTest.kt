// ArbitrationConfigTest.kt
package com.tmobile.arbitration

import org.junit.Assert.assertEquals
import org.junit.Test

class ArbitrationConfigTest {

    @Test
    fun testMetroZoneLimits() {
        val rules = ArbitrationConfig.getLimitsForPackage("com.example.metrozone")
        assertEquals(10, rules.maxRefreshesPerHour)
        assertEquals(5000L, rules.maxRefreshTimeMillis)
    }

    @Test
    fun testMetroPlayLimits() {
        val rules = ArbitrationConfig.getLimitsForPackage("com.example.metroplay")
        assertEquals(6, rules.maxRefreshesPerHour)
        assertEquals(6000L, rules.maxRefreshTimeMillis)
    }

    @Test
    fun testDefaultLimits() {
        val rules = ArbitrationConfig.getLimitsForPackage("com.unknown.app")
        assertEquals(5, rules.maxRefreshesPerHour)
        assertEquals(4000L, rules.maxRefreshTimeMillis)
    }
}