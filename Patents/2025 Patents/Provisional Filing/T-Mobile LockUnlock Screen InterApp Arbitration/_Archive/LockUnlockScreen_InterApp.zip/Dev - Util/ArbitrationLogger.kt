// ArbitrationLogger.kt
package com.tmobile.arbitration

import android.util.Log

object ArbitrationLogger {

    private const val TAG = "ArbitrationLog"

    fun debug(msg: String) {
        Log.d(TAG, msg)
    }

    fun warn(msg: String) {
        Log.w(TAG, msg)
    }

    fun error(msg: String, throwable: Throwable? = null) {
        Log.e(TAG, msg, throwable)
    }

    fun telemetry(event: String, data: Map<String, Any?>) {
        Log.d(TAG, "TELEMETRY - $event: $data")
    }
}