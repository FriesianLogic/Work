// ArbitrationRetryManager.kt
package com.tmobile.arbitration

import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.util.Log
import java.util.concurrent.ConcurrentHashMap

object ArbitrationRetryManager {

    private const val TAG = "ArbitrationRetry"
    private val retryCountMap = ConcurrentHashMap<String, Int>()
    private val hourlyLimitMap = ConcurrentHashMap<String, Int>()

    fun recordAttempt(packageName: String) {
        val current = retryCountMap.getOrDefault(packageName, 0)
        retryCountMap[packageName] = current + 1
        Log.d(TAG, "$packageName refresh attempt count: ${current + 1}")
    }

    fun getAttempts(packageName: String): Int {
        return retryCountMap.getOrDefault(packageName, 0)
    }

    fun resetHourlyCount() {
        retryCountMap.clear()
        Log.d(TAG, "Hourly retry counters reset")
    }

    fun scheduleRetry(context: Context, delayMillis: Long, jobId: Int, serviceClass: Class<*>) {
        val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        val component = ComponentName(context, serviceClass)
        val jobInfo = JobInfo.Builder(jobId, component)
            .setMinimumLatency(delayMillis)
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setPersisted(true)
            .build()

        val result = scheduler.schedule(jobInfo)
        Log.d(TAG, "Retry scheduled with job ID $jobId: $result")
    }
}