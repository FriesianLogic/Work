// ArbitrationLimits.java
package com.tmobile.arbitration;

import java.util.HashMap;
import java.util.Map;

public class ArbitrationLimits {

    public static class AppArbitrationRules {
        public final int maxRefreshesPerHour;
        public final long maxRefreshTimeMillis;

        public AppArbitrationRules(int maxRefreshes, long maxTimeMs) {
            this.maxRefreshesPerHour = maxRefreshes;
            this.maxRefreshTimeMillis = maxTimeMs;
        }
    }

    private static final Map<String, AppArbitrationRules> appConfig = new HashMap<>();

    static {
        appConfig.put("com.example.metrozone", new AppArbitrationRules(10, 5000));
        appConfig.put("com.example.metroplay", new AppArbitrationRules(6, 6000));
    }

    public static AppArbitrationRules getLimitsForPackage(String packageName) {
        if (appConfig.containsKey(packageName)) {
            return appConfig.get(packageName);
        } else {
            return getDefaultLimits();
        }
    }

    private static AppArbitrationRules getDefaultLimits() {
        return new AppArbitrationRules(5, 4000);
    }
}