// ArbitrationConfig.kt
package com.tmobile.arbitration

object ArbitrationConfig {

    private val appConfig = mapOf(
        "com.example.metrozone" to AppArbitrationRules(
            maxRefreshesPerHour = 10,
            maxRefreshTimeMillis = 5000
        ),
        "com.example.metroplay" to AppArbitrationRules(
            maxRefreshesPerHour = 6,
            maxRefreshTimeMillis = 6000
        )
    )

    fun getLimitsForPackage(packageName: String): AppArbitrationRules {
        return appConfig[packageName] ?: getDefaultLimits()
    }

    private fun getDefaultLimits(): AppArbitrationRules {
        return AppArbitrationRules(
            maxRefreshesPerHour = 5,
            maxRefreshTimeMillis = 4000
        )
    }

    data class AppArbitrationRules(
        val maxRefreshesPerHour: Int,
        val maxRefreshTimeMillis: Long
    )
}