
# Arbitration Module README

## Overview
This module provides a cooperative arbitration engine for two competing Android applications to fairly share content refresh opportunities during lock screen events.

### Key Features
- **Self-Tuning Behavior**: Apps tune their refresh request frequency and duration to avoid exceeding system thresholds.
- **Device and Network Awareness**: Refresh timing is adjusted based on whether the device is connected to Wi-Fi or carrier data and the device's performance characteristics.
- **Cooperative Arbitration**: Apps collaborate to allow each app to complete its refresh task without monopolizing the lock screen event.

## Modules
- **ArbitrationManager.kt / RefreshCoordinator.java**: Core arbitration logic.
- **ArbitrationConfig.kt / ArbitrationLimits.java**: Per-app configuration for refresh limits.
- **ArbitrationRetryManager.kt**: Retry manager for failed refresh attempts.
- **ArbitrationLogger.kt**: Telemetry and logging functionality.

## Installation and Integration
1. Integrate the arbitration engine into both competing apps (e.g., MetroZone and MetroPlay).
2. Use the `ArbitrationConfig` to set refresh limits per app (e.g., `maxRefreshesPerHour`).
3. Make sure both apps use `ArbitrationManager` to handle the arbitration flow during unlock screen events.
